chrome.runtime.onInstalled.addListener(() => {
  chrome.action.onClicked.addListener((tab) => {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"],
    });
  });
});


chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){
  if(request.type === "getTotal"){
    // console.log(request.data);
    let query = request.data;
    // console.log(query);
    let response;
    // console.log(request);
    fetch(request.url_api, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      // body: JSON.stringify(query)
      body: JSON.parse(query)
    })
    .then(response => response.json())
    .then(data => {sendResponse(data)})
    .catch(error => sendResponse(error));
    // sendResponse(response);
  }
  return true;
});


chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){
  if (request.type === 'notification') {
    chrome.notifications.create('', request.options, notificationId => {
      chrome.notifications.onClicked.addListener(id => {
        if (id === notificationId) {
          chrome.tabs.create({ url: request.url });
        }
      });
    });
    sendResponse({});
    return true;
  }
});

